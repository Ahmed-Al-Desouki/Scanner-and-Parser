﻿#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include<map>
#include <set>
#include<stack>
using namespace std;

vector<string> split(const string& str, char delimiter = ' ') {
	vector<string> tokens;
	stringstream ss(str);
	string token;

	while (getline(ss, token, delimiter))
		tokens.push_back(token);

	return tokens;
}

class DFA {
	private:
	map<pair<string, char>, string> transition_table;
	set<string> final_states;
	set<string> states;
	public:
	string start_state;
	string error_state;
	string current_state;
	string previous_state;

	void load_states(string filepath) {
		fstream file(filepath);

		if (!file) {
			cerr << "Error opening states file!\n";
			return;
		}

		string line;
		// read all states
		if (getline(file, line)) {
			vector<string> file_states = split(line, ',');
			// loop over each item in the vector
			for (string s : file_states) {
				states.insert(s);
			}
		}

		// read start state
		if (getline(file, line)) {
			start_state = line;
		}

		// read final states
		if (getline(file, line)) {
			vector<string> file_finale_states = split(line, ',');
			// loop over each item in the vector
			for (string s : file_finale_states) {
				final_states.insert(s);
			}
		}

		// read error state
		if (getline(file, line)) {
			error_state = line;
		}

		file.close();
	}

	void load_transition_table(string filepath){
		fstream file(filepath);

		if (!file) {
			cerr << "Error opening transtion table file!\n";
			return;
		}

		string line, current_s, next_state;
		char input;
		vector<string> l;

		while (getline(file, line)) {
			l = split(line);
			if (l.size() < 3) {
				cerr << "Invalid transition line: " << line << "\n";
				continue;
			}

			current_s = l[0];
			input = l[1].empty() ? '$' : l[1][0]; // vector of string but input should be char
			next_state = l[2];

			transition_table[{current_s, input}] = next_state;
		}

		file.close();
	}

	string move_to_next_state(string current_s, char input) {
		pair<string, char> key = { current_s, input};
		auto val = transition_table.find(key);

		if (val == transition_table.end()) {
			previous_state = current_state;
			current_state = error_state;
			return error_state;
		}

		previous_state = current_state;
		current_state = val->second;
		return val->second;
	}

	bool is_final_state(string state) {
		// if not found, find function return the iterator end of the set
		return final_states.find(state) != final_states.end();
	}

	void reset() {
		current_state = start_state;
		previous_state = start_state;
	}

	void print_transitions() {
		cout << "Current State | Input | Next State\n";
		cout << "--------------|-------|------------\n";

		for (const auto& entry : transition_table) {
			const string& current_state = entry.first.first;
			char input_symbol = entry.first.second;
			const string& next_state = entry.second;

			cout << "      " << current_state
				<< "       |   " << input_symbol
				<< "   |     " << next_state << "\n";
		}
	}
};

class Scanner {
	DFA dfa;
	map<string, string> final_state_to_token;
public:
	Scanner(string states_file, string transition_table_file, string token_file) {
		dfa.load_states(states_file);
		dfa.load_transition_table(transition_table_file);
		load_final_states_tokens(token_file);
	}

	void load_final_states_tokens(string filepath) {
		fstream file(filepath);

		if (!file) {
			cerr << "Error openning tokens file\n";
			return;
		}

		string line, state, token;
		vector<string> l;
		while (getline(file, line)) {
			l = split(line);
			state = l[0];
			token = l[1];
			final_state_to_token[state] = token;
		}

		file.close();
	}

	bool scan(string input_filepath, string output_filepath) {
		ifstream input_file(input_filepath);
		ofstream output_file(output_filepath);

		if (!input_file) {
			cerr << "Error openning input file\n";
			return false;
		}

		char ch;
		string current_state = dfa.start_state;
		string previous_state = dfa.previous_state;
		string lexeme = "";

		while (input_file.get(ch)) {
			previous_state = current_state;
			current_state = dfa.move_to_next_state(current_state, isspace(ch)? '$' : ch);

			if (current_state != dfa.error_state) {
				lexeme += ch;
			}
			else {
				if (dfa.is_final_state(previous_state)) {
					output_file << final_state_to_token[previous_state] << " " << lexeme << "\n";
					dfa.reset();
					current_state = dfa.start_state;
					previous_state = dfa.start_state;
					lexeme = "";

					input_file.unget();
				}
				else {
					cout << current_state << " " << previous_state << lexeme<<"\n";
					output_file << "Lexical Error :" << " " << ch << " " << "Invalid Character\n";
					output_file.close();
					return false;
				}
			}

		}
		if (dfa.is_final_state(current_state)) {
			output_file << final_state_to_token[current_state] << " " << lexeme << "\n";
		}

		return true;
	}
};

class LL1 {
    map<string, vector<vector<string>>> grammar;
    set<string> non_terminals;
    set<string> terminals;
    map<string, set<string>> first;
    map<string, set<string>> follow;
    map<pair<string, string>, vector<string>> parsing_table;
    string start_symbol;

public:
    LL1(string filepath) {
        load_grammer(filepath);
        compute_first_sets();
        compute_follow_sets();
        print_first_sets();
        print_follow_sets();
        build_parsing_table();
        print_parse_table(parsing_table);
    }

    void load_grammer(string filepath) {
        fstream file(filepath);

        if (!file) {
            cerr << "Can't open grammer file\n";
            return;
        }

        string line;
        vector<string>rule;
        while (getline(file, line)) {
            rule = split(line);
            string lhs = rule[0];

            // each lhs is non-terminal so add all non-terminals to non-terminals set
            non_terminals.insert(lhs);
            if (start_symbol.empty()) start_symbol = lhs;
            vector<string>rhs(rule.begin() + 1, rule.end());

            grammar[lhs].push_back(rhs);

            // add terminals from rhs to terminals set
            // if first character is uppercase then it is non-terminal 
            // else is terminal
            for (string& sym : rhs) {
                // Only add to terminals if not a non-terminal and not epsilon
                if (!isupper(sym[0]) && sym != "e")
                    terminals.insert(sym);
            }
        }

        file.close();
    }

    // Helper function to check if a production can derive epsilon
    bool can_derive_epsilon(const vector<string>& production) {
        for (const string& symbol : production) {
            if (symbol == "e") return true;
            if (terminals.count(symbol) > 0) return false;

            // If it's a non-terminal, check if it can derive epsilon
            if (first.count(symbol) > 0 && first[symbol].count("e") == 0) {
                return false;
            }
        }
        return true;
    }

    // Takes production rule and get first from it
    set<string> compute_first(const vector<string>& symbols) {
        set<string> result;

        // Empty production derives epsilon
        if (symbols.empty() || symbols[0] == "e") {
            result.insert("e");
            return result;
        }

        // If first element is terminal then add it to result set and return
        if (terminals.find(symbols[0]) != terminals.end()) {
            result.insert(symbols[0]);
            return result;
        }

        // By reaching this line then the first element is non-terminal
        bool all_derive_epsilon = true;

        for (size_t i = 0; i < symbols.size(); i++) {
            string sym = symbols[i];

            // If terminal, add it and break
            if (terminals.count(sym) > 0) {
                result.insert(sym);
                all_derive_epsilon = false;
                break;
            }

            // If non-terminal, add all non-epsilon symbols from its FIRST set
            if (non_terminals.count(sym) > 0) {
                // Make sure first set is computed for this non-terminal
                if (first.find(sym) == first.end()) {
                    first[sym] = {}; // Initialize to prevent recursion
                    for (auto& prod : grammar[sym]) {
                        set<string> temp_first = compute_first(prod);
                        first[sym].insert(temp_first.begin(), temp_first.end());
                    }
                }

                // Add everything except epsilon from FIRST(sym)
                for (const string& s : first[sym]) {
                    if (s != "e") {
                        result.insert(s);
                    }
                }

                // If this symbol cannot derive epsilon, we're done
                if (first[sym].count("e") == 0) {
                    all_derive_epsilon = false;
                    break;
                }
            }
        }

        // If all symbols can derive epsilon, add epsilon to result
        if (all_derive_epsilon) {
            result.insert("e");
        }

        return result;
    }

    void compute_first_sets() {
        bool changed;

        do {
            changed = false;

            // Loop over each rule in the grammar
            for (auto& rule : grammar) {
                // Get non-terminal (lhs)
                string A = rule.first;

                // Loop over each production rule in rhs
                for (auto& production : rule.second) {
                    // Compute first for each production rule
                    set<string> first_set = compute_first(production);

                    // Loop over each symbol in the computed first set
                    for (auto& sym : first_set) {
                        if (first[A].insert(sym).second)
                            changed = true;
                    }
                }
            }
        } while (changed);
    }

    void print_first_sets() {
        cout << "\n=== FIRST Sets ===\n";
        for (auto& f : first) {
            // Skip printing FIRST set for epsilon if it somehow got added
            if (f.first == "e") continue;

            cout << "FIRST(" << f.first << ") = { ";
            for (auto& sym : f.second) {
                cout << sym << " ";
            }
            cout << "}\n";
        }
    }

    void compute_follow_sets() {
        // Initialize FOLLOW set for start symbol with $
        follow[start_symbol].insert("$");

        bool changed;
        do {
            changed = false;

            // Loop over each rule in the grammar
            for (auto& rule : grammar) {
                // Non-terminal (lhs)
                string A = rule.first;

                // Loop over each production in the rule
                for (auto& production : rule.second) {
                    // Skip epsilon productions
                    if (production.size() == 1 && production[0] == "e") {
                        continue;
                    }

                    // Process each non-terminal in the production
                    for (size_t i = 0; i < production.size(); i++) {
                        string B = production[i];

                        // Only compute FOLLOW for non-terminals
                        if (non_terminals.count(B) == 0) {
                            continue;
                        }

                        // Case 1: B is followed by something
                        if (i < production.size() - 1) {
                            // Compute FIRST of everything that follows B
                            vector<string> beta(production.begin() + i + 1, production.end());
                            set<string> first_beta = compute_first(beta);

                            // Add FIRST(beta) - {epsilon} to FOLLOW(B)
                            bool beta_derives_epsilon = false;
                            for (const auto& sym : first_beta) {
                                if (sym == "e") {
                                    beta_derives_epsilon = true;
                                }
                                else if (follow[B].insert(sym).second) {
                                    changed = true;
                                }
                            }

                            // If beta can derive epsilon, add FOLLOW(A) to FOLLOW(B)
                            if (beta_derives_epsilon) {
                                for (const auto& sym : follow[A]) {
                                    if (follow[B].insert(sym).second) {
                                        changed = true;
                                    }
                                }
                            }
                        }
                        // Case 2: B is at the end of the production
                        else {
                            // Add FOLLOW(A) to FOLLOW(B)
                            for (const auto& sym : follow[A]) {
                                if (follow[B].insert(sym).second) {
                                    changed = true;
                                }
                            }
                        }
                    }
                }
            }
        } while (changed);
    }

    void print_follow_sets() {
        cout << "\n=== FOLLOW Sets ===\n";
        for (auto& f : follow) {
            // Skip printing FOLLOW set for epsilon if it somehow got added
            if (f.first == "e") continue;

            cout << "FOLLOW(" << f.first << ") = { ";
            for (auto& sym : f.second) {
                cout << sym << " ";
            }
            cout << "}\n";
        }
    }

    void build_parsing_table() {
        // Initialize all entries as error (empty vector)
        for (const auto& nt : non_terminals) {
            for (const auto& t : terminals) {
                parsing_table[{nt, t}] = {};
            }
            // Also initialize for end marker $
            parsing_table[{nt, "$"}] = {};
        }

        // For each production A → α
        for (const auto& rule : grammar) {
            string A = rule.first;

            // For each alternative of the production
            for (size_t i = 0; i < rule.second.size(); i++) {
                const vector<string>& production = rule.second[i];

                // Skip if production is already an error
                if (production.empty()) continue;

                // Special case: epsilon production
                if (production.size() == 1 && production[0] == "e") {
                    // For all terminals in FOLLOW(A), add A → ε
                    for (const auto& b : follow[A]) {
                        // Check for conflicts
                        if (!parsing_table[{A, b}].empty()) {
                            cerr << "Warning: Grammar is not LL(1). Conflict at M[" << A << ", " << b << "]" << endl;
                        }
                        parsing_table[{A, b}] = { "e" };
                    }
                    continue;
                }

                // Get FIRST(α)
                set<string> first_alpha = compute_first(production);

                // For each terminal or $ in FIRST(α), add A → α to table
                for (const auto& a : first_alpha) {
                    if (a != "e") {
                        // Check for conflicts
                        if (!parsing_table[{A, a}].empty()) {
                            cerr << "Warning: Grammar is not LL(1). Conflict at M[" << A << ", " << a << "]" << endl;
                        }
                        parsing_table[{A, a}] = production;
                    }
                }

                // If ε is in FIRST(α), for each terminal in FOLLOW(A), add A → α
                if (first_alpha.count("e") > 0) {
                    for (const auto& b : follow[A]) {
                        // Check for conflicts
                        if (!parsing_table[{A, b}].empty() && parsing_table[{A, b}] != production) {
                            cerr << "Warning: Grammar is not LL(1). Conflict at M[" << A << ", " << b << "]" << endl;
                        }
                        parsing_table[{A, b}] = production;
                    }
                }
            }
        }
    }

    void print_parse_table(const map<pair<string, string>, vector<string>>& table) {
        cout << "\n=== Parse Table ===\n";

        // Print only non-empty entries
        for (const auto& entry : table) {
            const string& non_terminal = entry.first.first;
            const string& terminal = entry.first.second;
            const vector<string>& production = entry.second;

            // Skip empty productions (error entries)
            if (production.empty()) continue;

            cout << "M[" << non_terminal << ", " << terminal << "] = ";
            for (const string& symbol : production) {
                cout << symbol << " ";
            }
            cout << endl;
        }

        cout << "===================" << endl;
    }


    void parse(const vector<string>& tokens) {
        stack<string> st;
        st.push("$");
        st.push(start_symbol);

        int index = 0;
        string current_token = tokens[index];

        cout << "\nParsing input: ";
        for (const auto& token : tokens) {
            cout << token << " ";
        }
        cout << "$\n\n";

        cout << "Parsing steps:\n";
        cout << "Stack\t\tInput\t\tAction\n";
        cout << "---------------------------------------------\n";

        while (!st.empty()) {
            // Print stack contents (for debugging)
            stack<string> temp_stack = st;
            string stack_contents;
            while (!temp_stack.empty()) {
                stack_contents = temp_stack.top() + " " + stack_contents;
                temp_stack.pop();
            }
            cout << stack_contents << "\t\t";

            // Print remaining input
            string remaining_input;
            for (size_t i = index; i < tokens.size(); i++) {
                remaining_input += tokens[i] + " ";
            }
            remaining_input += "$";
            cout << remaining_input << "\t\t";

            string top = st.top();
            st.pop();

            if (top == "e") {
                cout << "Skip epsilon\n";
                continue; // epsilon, skip
            }
            else if (terminals.count(top) || top == "$") {
                if (top == current_token) {
                    cout << "Match " << top << "\n";
                    index++;
                    if (index < tokens.size()) {
                        current_token = tokens[index];
                    }
                    else {
                        current_token = "$";
                    }
                }
                else {
                    cout << "Error: expected " << top << ", found " << current_token << "\n";
                    return;
                }
            }
            else if (non_terminals.count(top)) {
                auto entry = parsing_table.find({ top, current_token });
                if (entry == parsing_table.end() || entry->second.empty()) {
                    cout << "Error: no rule for [" << top << ", " << current_token << "]\n";
                    return;
                }

                const vector<string>& production = entry->second;
                cout << top << " -> ";
                for (const auto& sym : production) {
                    cout << sym << " ";
                }
                cout << "\n";

                // Push production in reverse
                if (!(production.size() == 1 && production[0] == "e")) {
                    for (auto it = production.rbegin(); it != production.rend(); ++it) {
                        st.push(*it);
                    }
                }
            }
            else {
                cout << "Error: unknown symbol " << top << "\n";
                return;
            }
        }

        if (current_token == "$") {
            cout << "\nParsing successful!\n";
        }
        else {
            cout << "\nError: input not fully consumed. Remaining token: " << current_token << "\n";
        }
    }

    vector<string> preprocess_tokens_from_file(const string& filepath) {
        vector<string> tokens;
        ifstream file(filepath);
        if (!file.is_open()) {
            cerr << "Failed to open scanned token file.\n";
            return tokens;
        }

        string line;
        while (getline(file, line)) {
            vector<string> v = split(line);
            string type = v[0];

            if (type == "ID") tokens.push_back("i");
            else if (type == "PLUS") tokens.push_back("+");
            else if (type == "MINUS") tokens.push_back("*");
            else if (type == "RIGHT_P") tokens.push_back(")");
            else if (type == "LEFT_P") tokens.push_back("(");
            else if (type == "SPACE") continue; // ignore spaces
            else {
                cerr << "Unknown token type: " << type << endl;
            }
        }

        file.close();
        return tokens;
    }
};

int main() {
	Scanner scanner("automaton.txt", "transitions.txt", "tokens.txt");
	scanner.scan("input.txt", "output.txt");

	LL1 parser("grammer.txt");

	parser.parse(parser.preprocess_tokens_from_file("output.txt"));

	return 0;
}